Open project in IntelliJ, press "Run" in the top left, then run 'HelloApplication'.
<br />
Select from Animation, Graphics, or About buttons. Use Back to Main button to go back to main.